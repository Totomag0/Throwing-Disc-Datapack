# En tant qu'objet au sol jamais vu. Un distributeur sans comportement spÃ©cial pour l'objet l'Ã©jecte :
# l'objet apparaÃ®t dans le bloc devant la face avant, sans lanceur (Thrower), avec un Age de 0.
tag @s add td.chk
execute unless items entity @s contents *[minecraft:custom_data~{td_disc:{}}] run return 0
execute if data entity @s Thrower run return 0
execute store result score #age td.tmp run data get entity @s Age
execute if score #age td.tmp matches 3.. run return 0

scoreboard players set #src td.tmp 1
# Cherche le distributeur collÃ© au bloc de l'objet, face avant tournÃ©e vers lui
execute align xyz positioned ~0.5 ~0.5 ~0.5 positioned ~-1 ~ ~ if block ~ ~ ~ minecraft:dispenser[facing=east] rotated -90 0 run return run function td_dispenser:launch
execute align xyz positioned ~0.5 ~0.5 ~0.5 positioned ~1 ~ ~ if block ~ ~ ~ minecraft:dispenser[facing=west] rotated 90 0 run return run function td_dispenser:launch
execute align xyz positioned ~0.5 ~0.5 ~0.5 positioned ~ ~ ~-1 if block ~ ~ ~ minecraft:dispenser[facing=south] rotated 0 0 run return run function td_dispenser:launch
execute align xyz positioned ~0.5 ~0.5 ~0.5 positioned ~ ~ ~1 if block ~ ~ ~ minecraft:dispenser[facing=north] rotated 180 0 run return run function td_dispenser:launch
execute align xyz positioned ~0.5 ~0.5 ~0.5 positioned ~ ~-1 ~ if block ~ ~ ~ minecraft:dispenser[facing=up] rotated 0 -90 run return run function td_dispenser:launch
execute align xyz positioned ~0.5 ~0.5 ~0.5 positioned ~ ~1 ~ if block ~ ~ ~ minecraft:dispenser[facing=down] rotated 0 90 run return run function td_dispenser:launch
