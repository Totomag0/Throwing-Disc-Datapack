kill @e[type=minecraft:marker,tag=td.home_cur]
function throwing_disc:disc/break
