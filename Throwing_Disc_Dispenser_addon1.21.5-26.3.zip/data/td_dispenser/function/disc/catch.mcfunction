# Le disque rentre dans son distributeur. Ce que Grappin a ramassÃ© tombe devant le distributeur.
execute at @n[type=minecraft:marker,tag=td.home_cur] rotated as @n[type=minecraft:marker,tag=td.home_cur] positioned ^ ^ ^0.7 run function throwing_disc:disc/grapple/release
data modify entity @s item.components."minecraft:item_model" set from entity @s item.components."minecraft:custom_data".td_disc.model
execute if function throwing_disc:disc/is_broken run return run function td_dispenser:disc/break

# RangÃ© dans la premiÃ¨re case libre ; distributeur cassÃ© ou plein : tombe devant
scoreboard players set #given td.tmp 0
execute at @n[type=minecraft:marker,tag=td.home_cur] if block ~ ~ ~ minecraft:dispenser store result score #given td.tmp run function td_dispenser:disc/store
execute if score #given td.tmp matches 0 at @n[type=minecraft:marker,tag=td.home_cur] rotated as @n[type=minecraft:marker,tag=td.home_cur] positioned ^ ^ ^0.7 run function throwing_disc:disc/spawn_item

execute at @n[type=minecraft:marker,tag=td.home_cur] run playsound minecraft:item.trident.return block @a ~ ~ ~ 1 1.2
kill @e[type=minecraft:marker,tag=td.home_cur]
kill @s
