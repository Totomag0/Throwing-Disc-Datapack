# Comme throwing_disc:disc/ench/colossus ; au retour, la cible est le distributeur
execute if score @s td.phase matches 1 run function throwing_disc:disc/ench/colossus_out
execute if score @s td.phase matches 2.. run function td_dispenser:disc/colossus_ret
scoreboard players operation @s td.prog > #p td.tmp

scoreboard players operation #size td.tmp = @s td.prog
scoreboard players operation #size td.tmp *= #colossus td.tmp
scoreboard players operation #size td.tmp /= #10 td.tmp
scoreboard players add #size td.tmp 100

execute store result storage throwing_disc:tmp box.s float 0.01 run scoreboard players get #size td.tmp
data modify storage td_dispenser:tmp o.s set from storage throwing_disc:tmp box.s

execute store result storage throwing_disc:tmp box.o double -0.005 run scoreboard players get #size td.tmp
scoreboard players remove #size td.tmp 100
execute store result storage throwing_disc:tmp box.d double 0.01 run scoreboard players get #size td.tmp
