# Retour : #p = 500 + 500 x (1 - dÂ² / d0Â²), d = distance au centre du distributeur (en centiÃ¨mes)
execute store result score #dx td.tmp run data get entity @s Pos[0] 100
execute store result score #dy td.tmp run data get entity @s Pos[1] 100
execute store result score #dz td.tmp run data get entity @s Pos[2] 100
execute store result score #ox td.tmp run data get entity @n[type=minecraft:marker,tag=td.home_cur] Pos[0] 100
execute store result score #oy td.tmp run data get entity @n[type=minecraft:marker,tag=td.home_cur] Pos[1] 100
execute store result score #oz td.tmp run data get entity @n[type=minecraft:marker,tag=td.home_cur] Pos[2] 100
scoreboard players operation #dx td.tmp -= #ox td.tmp
scoreboard players operation #dy td.tmp -= #oy td.tmp
scoreboard players operation #dz td.tmp -= #oz td.tmp
scoreboard players operation #dx td.tmp *= #dx td.tmp
scoreboard players operation #dy td.tmp *= #dy td.tmp
scoreboard players operation #dz td.tmp *= #dz td.tmp
scoreboard players operation #d2 td.tmp = #dx td.tmp
scoreboard players operation #d2 td.tmp += #dy td.tmp
scoreboard players operation #d2 td.tmp += #dz td.tmp

execute if score @s td.d0 matches ..0 run scoreboard players operation @s td.d0 = #d2 td.tmp
execute if score @s td.d0 matches ..0 run scoreboard players set @s td.d0 1

scoreboard players operation #q td.tmp = @s td.d0
scoreboard players operation #q td.tmp /= #500 td.tmp
execute if score #q td.tmp matches ..0 run scoreboard players set #q td.tmp 1
scoreboard players operation #p td.tmp = @s td.d0
scoreboard players operation #p td.tmp -= #d2 td.tmp
execute if score #p td.tmp matches ..-1 run scoreboard players set #p td.tmp 0
scoreboard players operation #p td.tmp /= #q td.tmp
scoreboard players operation #p td.tmp < #500 td.tmp
scoreboard players add #p td.tmp 500
