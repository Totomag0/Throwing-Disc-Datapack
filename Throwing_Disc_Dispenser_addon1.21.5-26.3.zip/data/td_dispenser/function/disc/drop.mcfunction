# Le disque tombe sur place (distributeur perdu ou vol trop long)
function throwing_disc:disc/grapple/release
data modify entity @s item.components."minecraft:item_model" set from entity @s item.components."minecraft:custom_data".td_disc.model
execute if function throwing_disc:disc/is_broken run return run function td_dispenser:disc/break
function throwing_disc:disc/spawn_item
kill @e[type=minecraft:marker,tag=td.home_cur]
kill @s
