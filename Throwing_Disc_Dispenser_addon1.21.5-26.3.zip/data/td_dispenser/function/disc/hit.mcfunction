# En tant qu'entitÃ© touchÃ©e (comme throwing_disc:disc/hit, sans Butin)
scoreboard players operation #hit td.tmp = #dmg10 td.tmp
execute if score #smite td.tmp matches 1.. if entity @s[type=#minecraft:sensitive_to_smite] run function throwing_disc:disc/ench/smite
execute if score #bane td.tmp matches 1.. if entity @s[type=#minecraft:sensitive_to_bane_of_arthropods] run function throwing_disc:disc/ench/bane

execute store result storage throwing_disc:tmp hit.amount float 0.1 run scoreboard players get #hit td.tmp
scoreboard players set #ok td.tmp 0
function td_dispenser:disc/deal with storage throwing_disc:tmp hit
execute if score #ok td.tmp matches 0 run return 0

execute at @s run particle minecraft:crit ~ ~1 ~ 0.2 0.3 0.2 0.1 4
execute if score #bane td.tmp matches 1.. if entity @s[type=#minecraft:sensitive_to_bane_of_arthropods] run effect give @s minecraft:slowness 2 3
execute if score #fire td.tmp matches 1.. run function throwing_disc:disc/ench/fire
