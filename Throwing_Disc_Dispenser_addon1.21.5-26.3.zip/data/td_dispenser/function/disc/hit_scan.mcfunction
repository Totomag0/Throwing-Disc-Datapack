# Comme throwing_disc:disc/hit_scan (sans lanceur : les joueurs peuvent aussi Ãªtre touchÃ©s)
execute if score #colossus td.tmp matches 1.. run return run function td_dispenser:disc/hit_scan_big with storage throwing_disc:tmp box
execute positioned ~-0.5 ~-0.5 ~-0.5 as @e[dx=0,dy=0,dz=0,type=!#throwing_disc:not_hittable] run function td_dispenser:disc/hit
