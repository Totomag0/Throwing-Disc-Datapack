$execute positioned ~$(o) ~$(o) ~$(o) as @e[dx=$(d),dy=$(d),dz=$(d),type=!#throwing_disc:not_hittable] run function td_dispenser:disc/hit
