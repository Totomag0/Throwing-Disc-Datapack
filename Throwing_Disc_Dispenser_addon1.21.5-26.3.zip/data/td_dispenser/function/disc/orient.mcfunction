# En tant que disque. Vol plutôt horizontal : couché (90° sur X, comme le pack principal).
# Vol plutôt vertical (plus de 45°) : debout (90° sur Y).
execute store result score #pt td.tmp run data get entity @s Rotation[1] 100
data modify storage td_dispenser:tmp o.a set value 1.5707964f
data modify storage td_dispenser:tmp o.ax set value [1f,0f,0f]
execute unless score #pt td.tmp matches -4500..4500 run data modify storage td_dispenser:tmp o.ax set value [0f,1f,0f]
function td_dispenser:disc/orient_apply with storage td_dispenser:tmp o
