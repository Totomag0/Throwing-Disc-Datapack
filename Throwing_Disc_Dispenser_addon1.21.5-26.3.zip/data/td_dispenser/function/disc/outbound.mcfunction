# Phase 1 : aller en ligne droite, ricochets compris
scoreboard players remove @s td.timer 1
execute if score #steps td.tmp matches 1.. run function td_dispenser:disc/out_step
execute if score @s td.timer matches ..0 run scoreboard players set @s td.phase 2
