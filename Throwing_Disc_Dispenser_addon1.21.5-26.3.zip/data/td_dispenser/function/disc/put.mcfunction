$item replace block ~ ~ ~ container.$(slot) from entity @s contents
return 1
