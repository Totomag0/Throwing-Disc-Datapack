# Comme throwing_disc:disc/read_enchants, mais Colosse grandit vers le distributeur (pas de joueur)
execute store result score #dmg10 td.tmp run data get entity @s item.components."minecraft:custom_data".td_disc.damage 10
execute store result score #sharp td.tmp run data get entity @s item.components."minecraft:enchantments"."minecraft:sharpness"
execute store result score #smite td.tmp run data get entity @s item.components."minecraft:enchantments"."minecraft:smite"
execute store result score #bane td.tmp run data get entity @s item.components."minecraft:enchantments"."minecraft:bane_of_arthropods"
execute store result score #fire td.tmp run data get entity @s item.components."minecraft:enchantments"."minecraft:fire_aspect"
execute store result score #grapple td.tmp run data get entity @s item.components."minecraft:enchantments"."throwing_disc:grapple"
execute store result score #tornado td.tmp run data get entity @s item.components."minecraft:enchantments"."throwing_disc:tornado"
execute store result score #colossus td.tmp run data get entity @s item.components."minecraft:enchantments"."throwing_disc:colossus"
# Butin : sans joueur, pas de butin bonus
scoreboard players set #loot td.tmp 0

execute if score #sharp td.tmp matches 1.. run scoreboard players operation #add td.tmp = #sharp td.tmp
execute if score #sharp td.tmp matches 1.. run scoreboard players operation #add td.tmp *= #5 td.tmp
execute if score #sharp td.tmp matches 1.. run scoreboard players add #add td.tmp 5
execute if score #sharp td.tmp matches 1.. run scoreboard players operation #dmg10 td.tmp += #add td.tmp

execute if score #colossus td.tmp matches 1.. run function td_dispenser:disc/colossus
