# Un pas de 0.2 bloc au retour
execute at @s if block ^ ^ ^0.2 minecraft:decorated_pot positioned ^ ^ ^0.2 run function throwing_disc:disc/break_pot
execute at @s run tp @s ^ ^ ^0.2
execute at @s run function td_dispenser:disc/hit_scan
execute if score #grapple td.tmp matches 1.. at @s run function throwing_disc:disc/grapple/scan
execute at @s if entity @e[type=minecraft:marker,tag=td.home_cur,distance=..0.8] run return run function td_dispenser:disc/catch

scoreboard players remove #steps td.tmp 1
execute if score #steps td.tmp matches 1.. run function td_dispenser:disc/ret_step
