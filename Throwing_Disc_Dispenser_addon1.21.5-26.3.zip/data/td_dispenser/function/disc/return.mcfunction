# Phase 2 : retour vers le centre du distributeur, traverse les blocs, accélère
scoreboard players add @s td.speed 6
scoreboard players operation @s td.speed < #max_return td.tmp
execute store result score #yw td.tmp run data get entity @s Rotation[0] 100
# (forme "tp ... facing" : "execute facing ... run tp ~ ~" ne retourne pas un disque qui pointe pile vers le haut)
execute at @s run tp @s ~ ~ ~ facing entity @n[type=minecraft:marker,tag=td.home_cur] feet
# Presque à la verticale, la direction gauche/droite n'a plus de sens : on garde l'ancienne
execute store result score #pt td.tmp run data get entity @s Rotation[1] 100
execute unless score #pt td.tmp matches -8000..8000 store result entity @s Rotation[0] float 0.01 run scoreboard players get #yw td.tmp
execute at @s if entity @e[type=minecraft:marker,tag=td.home_cur,distance=..0.8] run return run function td_dispenser:disc/catch
execute if score #steps td.tmp matches 1.. run function td_dispenser:disc/ret_step
