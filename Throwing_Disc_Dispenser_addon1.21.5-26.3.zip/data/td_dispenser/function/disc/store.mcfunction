# En tant que disque, positionnÃ© sur le distributeur : 1 si rangÃ©, 0 si plein
execute unless items block ~ ~ ~ container.0 * run return run function td_dispenser:disc/put {slot:0}
execute unless items block ~ ~ ~ container.1 * run return run function td_dispenser:disc/put {slot:1}
execute unless items block ~ ~ ~ container.2 * run return run function td_dispenser:disc/put {slot:2}
execute unless items block ~ ~ ~ container.3 * run return run function td_dispenser:disc/put {slot:3}
execute unless items block ~ ~ ~ container.4 * run return run function td_dispenser:disc/put {slot:4}
execute unless items block ~ ~ ~ container.5 * run return run function td_dispenser:disc/put {slot:5}
execute unless items block ~ ~ ~ container.6 * run return run function td_dispenser:disc/put {slot:6}
execute unless items block ~ ~ ~ container.7 * run return run function td_dispenser:disc/put {slot:7}
execute unless items block ~ ~ ~ container.8 * run return run function td_dispenser:disc/put {slot:8}
return 0
