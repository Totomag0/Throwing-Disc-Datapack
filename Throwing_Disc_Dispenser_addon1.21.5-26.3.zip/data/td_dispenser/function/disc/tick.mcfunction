# En tant que disque lancÃ© par un distributeur, Ã  sa position
scoreboard players add @s td.life 1
tag @e[type=minecraft:item_display,tag=td.self] remove td.self
tag @s add td.self
scoreboard players operation #did td.tmp = @s td.did

# Retrouve son distributeur
tag @e[type=minecraft:marker,tag=td.home_cur] remove td.home_cur
execute as @e[type=minecraft:marker,tag=td.home] if score @s td.did = #did td.tmp run tag @s add td.home_cur
scoreboard players set @e[type=minecraft:marker,tag=td.home_cur] td.life 0

data modify storage td_dispenser:tmp o.s set value 1f
function td_dispenser:disc/read_enchants

# Distributeur introuvable / trop loin, ou vol trop long : le disque tombe au sol
execute unless entity @e[type=minecraft:marker,tag=td.home_cur,distance=..96] run return run function td_dispenser:disc/drop
execute if score @s td.life matches 400.. run return run function td_dispenser:disc/drop

# Nombre de pas de 0.2 bloc ce tick
scoreboard players operation @s td.acc += @s td.speed
scoreboard players operation #steps td.tmp = @s td.acc
scoreboard players operation #steps td.tmp /= #20 td.tmp
scoreboard players operation @s td.acc %= #20 td.tmp

# Son de rotation
scoreboard players operation #m td.tmp = @s td.life
scoreboard players operation #m td.tmp %= #4 td.tmp
execute if score #m td.tmp matches 0 run playsound minecraft:entity.player.attack.sweep block @a ~ ~ ~ 0.25 1.9

scoreboard players operation #ph td.tmp = @s td.phase
execute if score #ph td.tmp matches 1 run function td_dispenser:disc/outbound
execute if score #ph td.tmp matches 2.. run function td_dispenser:disc/return

execute if score #tornado td.tmp matches 1.. at @s run function throwing_disc:disc/ench/tornado
execute if entity @s[tag=td.has_item] at @s run function throwing_disc:disc/grapple/carry
execute if score @s td.xp matches 1.. if score #m td.tmp matches 0 at @s run particle minecraft:happy_villager ~ ~ ~ 0.15 0.15 0.15 0 1

# Le disque reste à plat quelle que soit l'inclinaison de son vol (sauf s'il vient d'être rangé ou de tomber)
execute if entity @e[type=minecraft:item_display,tag=td.self] run function td_dispenser:disc/orient
