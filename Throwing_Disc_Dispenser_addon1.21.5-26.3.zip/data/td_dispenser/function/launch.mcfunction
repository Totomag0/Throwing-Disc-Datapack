# PositionnÃ© au centre du distributeur, tournÃ© vers sa face avant.
# Source du disque : #src = 1 -> objet au sol (@s), #src = 2 -> storage td_dispenser:tmp item
# RepÃ¨re du distributeur (le disque y revient)
summon minecraft:marker ~ ~ ~ {Tags:["td.home","td.newhome"]}
tp @n[type=minecraft:marker,tag=td.newhome] ~ ~ ~ ~ ~
scoreboard players set @n[type=minecraft:marker,tag=td.newhome] td.life 0

# MÃªme disque en vol que celui d'un joueur (rotation adaptÃ©e Ã  la version via l'overlay du pack principal)
execute positioned ^ ^ ^0.7 run function throwing_disc:throw/spawn
tag @n[type=minecraft:item_display,tag=td.new] add td.ddisc
tag @n[type=minecraft:item_display,tag=td.new] add td.newd
tag @n[type=minecraft:item_display,tag=td.new] remove td.disc
execute if score #src td.tmp matches 1 run item replace entity @n[type=minecraft:item_display,tag=td.new] contents from entity @s contents
execute if score #src td.tmp matches 2 run data modify entity @n[type=minecraft:item_display,tag=td.new] item set from storage td_dispenser:tmp item
scoreboard players set @n[type=minecraft:item_display,tag=td.new] td.owner 0
scoreboard players set #hand td.tmp 0
# Le distributeur use le disque comme un joueur en survie
scoreboard players set #creative td.tmp 0
execute as @n[type=minecraft:item_display,tag=td.new] run function throwing_disc:throw/init

scoreboard players operation @n[type=minecraft:marker,tag=td.newhome] td.did = @n[type=minecraft:item_display,tag=td.newd] td.did
tag @e[type=minecraft:marker,tag=td.newhome] remove td.newhome
tag @e[type=minecraft:item_display,tag=td.newd] remove td.newd
execute if score #src td.tmp matches 1 run kill @s
