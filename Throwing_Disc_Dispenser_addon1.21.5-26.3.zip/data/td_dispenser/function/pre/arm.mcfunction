# Au centre du distributeur, avant son tir : tous les disques sont mis de cÃ´tÃ© dans un marker
# (le tir vanilla ne trouvera donc pas de disque), le premier est lancÃ©, les autres reviennent ensuite.
summon minecraft:marker ~ ~ ~ {Tags:["td.armed","td.newarm"],data:{items:[]}}
scoreboard players set @n[type=minecraft:marker,tag=td.newarm] td.life 0
data modify entity @n[type=minecraft:marker,tag=td.newarm] data.items append from block ~ ~ ~ Items[{components:{"minecraft:custom_data":{td_disc:{}}}}]
data remove block ~ ~ ~ Items[{components:{"minecraft:custom_data":{td_disc:{}}}}]

data modify storage td_dispenser:tmp item set from entity @n[type=minecraft:marker,tag=td.newarm] data.items[0]
data remove storage td_dispenser:tmp item.Slot
data remove entity @n[type=minecraft:marker,tag=td.newarm] data.items[0]
tag @e[type=minecraft:marker,tag=td.newarm] remove td.newarm

scoreboard players set #src td.tmp 2
execute if block ~ ~ ~ minecraft:dispenser[facing=east] rotated -90 0 run return run function td_dispenser:launch
execute if block ~ ~ ~ minecraft:dispenser[facing=west] rotated 90 0 run return run function td_dispenser:launch
execute if block ~ ~ ~ minecraft:dispenser[facing=south] rotated 0 0 run return run function td_dispenser:launch
execute if block ~ ~ ~ minecraft:dispenser[facing=north] rotated 180 0 run return run function td_dispenser:launch
execute if block ~ ~ ~ minecraft:dispenser[facing=up] rotated 0 -90 run return run function td_dispenser:launch
execute if block ~ ~ ~ minecraft:dispenser[facing=down] rotated 0 90 run return run function td_dispenser:launch
