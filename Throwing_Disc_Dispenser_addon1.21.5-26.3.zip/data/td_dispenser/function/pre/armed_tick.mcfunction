# En tant que marker d'un distributeur activÃ©.
# 6 ticks : le tir vanilla (4 ticks aprÃ¨s l'activation) est passÃ©, les autres disques reviennent.
# Le marker reste tant que le distributeur est alimentÃ© : un seul lancer par activation.
scoreboard players add @s td.life 1
execute if score @s td.life matches 6 run function td_dispenser:pre/restore
execute if score @s td.life matches 6.. unless block ~ ~ ~ minecraft:dispenser[triggered=true] run kill @s
