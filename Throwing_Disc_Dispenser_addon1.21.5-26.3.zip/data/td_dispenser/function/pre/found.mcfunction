# PositionnÃ© sur le coin d'un distributeur activÃ© (triggered=true), prÃ¨s d'un joueur
execute positioned ~0.5 ~0.5 ~0.5 if entity @e[type=minecraft:marker,tag=td.armed,distance=..0.1] run return 0
execute unless items block ~ ~ ~ container.* *[minecraft:custom_data~{td_disc:{}}] run return 0
execute positioned ~0.5 ~0.5 ~0.5 run function td_dispenser:pre/arm
