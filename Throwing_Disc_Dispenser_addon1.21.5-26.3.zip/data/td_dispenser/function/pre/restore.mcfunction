# Les disques mis de cÃ´tÃ© reprennent leur case ; distributeur cassÃ© : ils tombent au sol
execute if block ~ ~ ~ minecraft:dispenser run data modify block ~ ~ ~ Items append from entity @s data.items[]
execute unless block ~ ~ ~ minecraft:dispenser if data entity @s data.items[0] run function td_dispenser:pre/spill
data modify entity @s data.items set value []
