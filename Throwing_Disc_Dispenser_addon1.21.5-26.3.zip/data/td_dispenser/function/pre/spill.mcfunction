# Fait tomber un disque mis de cÃ´tÃ©, puis recommence tant qu'il en reste
data modify storage td_dispenser:tmp item set from entity @s data.items[0]
data remove storage td_dispenser:tmp item.Slot
data remove entity @s data.items[0]
summon minecraft:item ~ ~ ~ {Tags:["td.newitem","td.chk"],PickupDelay:10s,Item:{id:"minecraft:stick",count:1}}
data modify entity @n[type=minecraft:item,tag=td.newitem] Item set from storage td_dispenser:tmp item
tag @e[type=minecraft:item,tag=td.newitem] remove td.newitem
execute if data entity @s data.items[0] run function td_dispenser:pre/spill
