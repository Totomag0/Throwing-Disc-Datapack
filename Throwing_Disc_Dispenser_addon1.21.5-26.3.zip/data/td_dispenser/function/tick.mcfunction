# RepÃ¨res des distributeurs (marker au centre du bloc) : supprimÃ©s si leur disque n'existe plus depuis 5 ticks
scoreboard players add @e[type=minecraft:marker,tag=td.home] td.life 1
kill @e[type=minecraft:marker,tag=td.home,scores={td.life=5..}]

# Un distributeur activÃ© tire 4 ticks plus tard. PrÃ¨s d'un joueur, l'objet Ã©jectÃ© serait ramassÃ©
# avant qu'on puisse le voir : le disque est donc lancÃ© dÃ¨s l'activation (voir pre/).
execute as @a[gamemode=!spectator] at @s align xyz run function td_dispenser:pre/scan
execute as @e[type=minecraft:marker,tag=td.armed] at @s run function td_dispenser:pre/armed_tick

# Loin des joueurs : le disque Ã©jectÃ© par le distributeur est remplacÃ© par un disque lancÃ©
execute as @e[type=minecraft:item,tag=!td.chk] at @s run function td_dispenser:check

# Disques lancÃ©s par un distributeur
execute as @e[type=minecraft:item_display,tag=td.ddisc] at @s run function td_dispenser:disc/tick
