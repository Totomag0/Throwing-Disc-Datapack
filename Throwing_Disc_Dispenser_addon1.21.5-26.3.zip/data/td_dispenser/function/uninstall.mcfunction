# Fait tomber les disques lancÃ©s par des distributeurs, rend les disques mis de cÃ´tÃ©, puis supprime les repÃ¨res.
# (Ã€ lancer AVANT throwing_disc:uninstall, qui supprime les scoreboards.)
execute as @e[type=minecraft:item_display,tag=td.ddisc] at @s run function td_dispenser:uninstall_one
execute as @e[type=minecraft:marker,tag=td.armed] at @s run function td_dispenser:pre/restore
kill @e[type=minecraft:marker,tag=td.home]
kill @e[type=minecraft:marker,tag=td.armed]
tag @e[type=minecraft:item,tag=td.chk] remove td.chk
data remove storage td_dispenser:tmp item
data remove storage td_dispenser:tmp o
