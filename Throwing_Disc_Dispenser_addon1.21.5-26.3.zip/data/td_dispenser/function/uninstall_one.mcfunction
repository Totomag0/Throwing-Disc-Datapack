scoreboard players operation #did td.tmp = @s td.did
tag @e[type=minecraft:marker,tag=td.home_cur] remove td.home_cur
function td_dispenser:disc/drop
