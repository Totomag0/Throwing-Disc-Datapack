playsound minecraft:entity.item.break player @a ~ ~ ~ 1 1
particle minecraft:crit ~ ~ ~ 0.2 0.2 0.2 0.2 12
kill @s
