# Positionné sur un pot décoré : le pot disparaît sans se drop, seul son contenu tombe
execute align xyz positioned ~0.5 ~0.5 ~0.5 if data block ~ ~ ~ item run function throwing_disc:disc/pot_contents
execute align xyz positioned ~0.5 ~0.5 ~0.5 run particle minecraft:block{block_state:"minecraft:decorated_pot"} ~ ~ ~ 0.25 0.25 0.25 0 20
execute align xyz positioned ~0.5 ~0.5 ~0.5 run playsound minecraft:block.decorated_pot.shatter block @a ~ ~ ~ 1 1
setblock ~ ~ ~ minecraft:air
