# Le lanceur rattrape le disque : retour dans la main d'origine si elle est libre, sinon dans l'inventaire
execute at @a[tag=td.owner,limit=1] run function throwing_disc:disc/grapple/release
data modify entity @s item.components."minecraft:item_model" set from entity @s item.components."minecraft:custom_data".td_disc.model
execute if function throwing_disc:disc/is_broken run return run function throwing_disc:disc/break

scoreboard players set #given td.tmp 0
execute if score @s td.hand matches 1 as @a[tag=td.owner,limit=1] unless items entity @s weapon.mainhand * run function throwing_disc:disc/give_main
execute if score @s td.hand matches 2 as @a[tag=td.owner,limit=1] unless items entity @s weapon.offhand * run function throwing_disc:disc/give_off
execute if score #given td.tmp matches 0 at @a[tag=td.owner,limit=1] run function throwing_disc:disc/spawn_item

execute at @a[tag=td.owner,limit=1] run playsound minecraft:item.trident.return player @a ~ ~ ~ 1 1.2
kill @s
