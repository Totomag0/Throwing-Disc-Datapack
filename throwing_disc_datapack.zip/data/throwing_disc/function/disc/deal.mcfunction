$execute store success score #ok td.tmp run damage @s $(amount) throwing_disc:throwing_disc by @n[type=minecraft:item_display,tag=td.self] from @a[tag=td.owner,limit=1]
