# Le lanceur n'est plus là : le disque tombe sur place
function throwing_disc:disc/grapple/release
data modify entity @s item.components."minecraft:item_model" set from entity @s item.components."minecraft:custom_data".td_disc.model
execute if function throwing_disc:disc/is_broken run return run function throwing_disc:disc/break
function throwing_disc:disc/spawn_item
kill @s
