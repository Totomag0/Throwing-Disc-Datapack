scoreboard players operation #add td.tmp = #bane td.tmp
scoreboard players operation #add td.tmp *= #25 td.tmp
scoreboard players operation #hit td.tmp += #add td.tmp
