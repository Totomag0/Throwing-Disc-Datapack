# Colosse (custom) : en tant que disque.
# Taille max : I = x2, II = x3, III = x4, atteinte quand le disque revient au lanceur.
# Progression (0 à 1000), qui ne recule jamais :
#   aller  : 0 -> 500 selon le temps écoulé / durée totale de l'aller (ricochets compris)
#   retour : 500 -> 1000 selon le rapprochement du lanceur
# Taille (en %) = 100 + progression x niveau / 10. La hitbox suit la taille, pas les dégâts.
execute if score @s td.phase matches 1 run function throwing_disc:disc/ench/colossus_out
execute if score @s td.phase matches 2.. run function throwing_disc:disc/ench/colossus_ret
scoreboard players operation @s td.prog > #p td.tmp

scoreboard players operation #size td.tmp = @s td.prog
scoreboard players operation #size td.tmp *= #colossus td.tmp
scoreboard players operation #size td.tmp /= #10 td.tmp
scoreboard players add #size td.tmp 100

# Visuel : toute la transformation est réécrite (même rotation qu'au lancer), interpolée sur 1 tick
execute store result storage throwing_disc:tmp box.s float 0.01 run scoreboard players get #size td.tmp
function throwing_disc:disc/ench/colossus_scale with storage throwing_disc:tmp box

# Hitbox : cube de côté = taille, centré sur le disque (o = -côté/2, d = côté - 1)
execute store result storage throwing_disc:tmp box.o double -0.005 run scoreboard players get #size td.tmp
scoreboard players remove #size td.tmp 100
execute store result storage throwing_disc:tmp box.d double 0.01 run scoreboard players get #size td.tmp
