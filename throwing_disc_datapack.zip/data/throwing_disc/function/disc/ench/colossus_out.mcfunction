# Aller : #p = 500 x temps écoulé / (temps écoulé + temps restant)
scoreboard players operation #den td.tmp = @s td.life
scoreboard players operation #den td.tmp += @s td.timer
execute if score #den td.tmp matches ..0 run scoreboard players set #den td.tmp 1
scoreboard players operation #p td.tmp = @s td.life
scoreboard players operation #p td.tmp *= #500 td.tmp
scoreboard players operation #p td.tmp /= #den td.tmp
scoreboard players operation #p td.tmp < #500 td.tmp
