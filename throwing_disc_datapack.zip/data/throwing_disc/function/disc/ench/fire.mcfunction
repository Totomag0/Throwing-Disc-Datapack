# Aura de feu (Fire Aspect) : 4 s de feu par niveau.
# Les données d'un joueur ne sont pas modifiables : ne s'applique qu'aux mobs.
execute if entity @s[type=minecraft:player] run return 0
scoreboard players operation #f td.tmp = #fire td.tmp
scoreboard players operation #f td.tmp *= #80 td.tmp
execute store result entity @s Fire short 1 run scoreboard players get #f td.tmp
