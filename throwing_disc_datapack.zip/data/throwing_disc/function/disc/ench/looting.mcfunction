# Butin (Looting) : en tant qu'entité touchée.
# Le butin vanilla lit l'enchantement dans la main principale de l'attaquant au moment de la mort.
# On échange donc, le temps du coup (même tick, même fonction), l'objet en main du lanceur avec le disque,
# puis on remet tout en place. L'objet du joueur est gardé dans un item_display temporaire.
execute at @n[type=minecraft:item_display,tag=td.self] run summon minecraft:item_display ~ ~ ~ {Tags:["td.swap"]}
item replace entity @n[type=minecraft:item_display,tag=td.swap] contents from entity @a[tag=td.owner,limit=1] weapon.mainhand
item replace entity @a[tag=td.owner,limit=1] weapon.mainhand from entity @n[type=minecraft:item_display,tag=td.self] contents
function throwing_disc:disc/deal with storage throwing_disc:tmp hit
item replace entity @a[tag=td.owner,limit=1] weapon.mainhand from entity @n[type=minecraft:item_display,tag=td.swap] contents
kill @e[type=minecraft:item_display,tag=td.swap]
