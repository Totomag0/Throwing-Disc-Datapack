# Tornade (custom) : en tant que disque, à sa position, chaque tick.
# Les mobs entre 1.5 et 6 blocs sont aspirés vers le disque (mouvement physique : pas à travers les murs).
# Le mouvement d'un joueur n'est pas modifiable par commande : seuls les mobs sont attirés.
# Le disque vient d'être rattrapé ou est tombé ce tick : plus rien à attirer
execute unless entity @e[type=minecraft:item_display,tag=td.self] run return 0
execute as @e[distance=1.5..6,type=!#throwing_disc:not_hittable,type=!minecraft:player,tag=!td.owner] run function throwing_disc:disc/ench/tornado_pull
particle minecraft:small_gust ~ ~ ~ 0.6 0.3 0.6 0 2
