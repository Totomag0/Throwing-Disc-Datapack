# En tant que mob attiré : vitesse de 0.35 bloc/tick dans la direction du disque
execute at @s facing entity @n[type=minecraft:item_display,tag=td.self] feet run summon minecraft:marker ^ ^ ^1 {Tags:["td.vec"]}
execute store result score #mx td.tmp run data get entity @n[type=minecraft:marker,tag=td.vec] Pos[0] 1000
execute store result score #my td.tmp run data get entity @n[type=minecraft:marker,tag=td.vec] Pos[1] 1000
execute store result score #mz td.tmp run data get entity @n[type=minecraft:marker,tag=td.vec] Pos[2] 1000
kill @e[type=minecraft:marker,tag=td.vec]
execute store result score #px td.tmp run data get entity @s Pos[0] 1000
execute store result score #py td.tmp run data get entity @s Pos[1] 1000
execute store result score #pz td.tmp run data get entity @s Pos[2] 1000
scoreboard players operation #mx td.tmp -= #px td.tmp
scoreboard players operation #my td.tmp -= #py td.tmp
scoreboard players operation #mz td.tmp -= #pz td.tmp
execute store result entity @s Motion[0] double 0.00035 run scoreboard players get #mx td.tmp
execute store result entity @s Motion[1] double 0.00035 run scoreboard players get #my td.tmp
execute store result entity @s Motion[2] double 0.00035 run scoreboard players get #mz td.tmp
