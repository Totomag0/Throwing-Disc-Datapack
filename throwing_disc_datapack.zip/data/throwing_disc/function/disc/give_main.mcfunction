# En tant que lanceur
item replace entity @s weapon.mainhand from entity @n[type=minecraft:item_display,tag=td.self] contents
scoreboard players set #given td.tmp 1
