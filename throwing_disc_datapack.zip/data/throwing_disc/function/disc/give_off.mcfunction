# En tant que lanceur
item replace entity @s weapon.offhand from entity @n[type=minecraft:item_display,tag=td.self] contents
scoreboard players set #given td.tmp 1
