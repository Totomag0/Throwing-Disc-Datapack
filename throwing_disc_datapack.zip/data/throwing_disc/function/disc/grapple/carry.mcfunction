# En tant que disque, à sa position et avec sa rotation : l'objet porté se cale sur le disque
execute as @e[type=minecraft:item_display,tag=td.carried] if score @s td.did = #did td.tmp run function throwing_disc:disc/grapple/follow
