# En tant qu'objet porté (item_display)
tp @s ~ ~ ~ ~ ~
scoreboard players set @s td.life 0
