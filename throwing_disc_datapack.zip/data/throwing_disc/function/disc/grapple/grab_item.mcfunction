# En tant qu'objet au sol. On n'accroche pas un autre disque.
execute if items entity @s contents *[minecraft:custom_data~{td_disc:{}}] run return 0

# L'objet devient un item_display debout sur le disque (même interpolation que le disque = fluide).
# Il garde la pile entière (1 à 99) et redevient un objet normal au retour.
execute at @n[type=minecraft:item_display,tag=td.self] run summon minecraft:item_display ~ ~ ~ {Tags:["td.carried","td.newcarry"],teleport_duration:1,item_display:"fixed",transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0.25f,0f],scale:[0.45f,0.45f,0.45f]},item:{id:"minecraft:stone",count:1}}
item replace entity @n[type=minecraft:item_display,tag=td.newcarry] contents from entity @s contents
scoreboard players operation @n[type=minecraft:item_display,tag=td.newcarry] td.did = #did td.tmp
scoreboard players set @n[type=minecraft:item_display,tag=td.newcarry] td.life 0
execute as @n[type=minecraft:item_display,tag=td.newcarry] at @n[type=minecraft:item_display,tag=td.self] run tp @s ~ ~ ~ ~ ~
tag @e[type=minecraft:item_display,tag=td.newcarry] remove td.newcarry

tag @n[type=minecraft:item_display,tag=td.self] add td.has_item
playsound minecraft:entity.item.pickup player @a ~ ~ ~ 0.6 1.3
kill @s
