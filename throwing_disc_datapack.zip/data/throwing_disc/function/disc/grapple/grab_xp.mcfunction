# En tant qu'orbe d'XP : sa valeur totale (Value x Count) est stockée dans le disque
execute store result score #v td.tmp run data get entity @s Value
execute store result score #c td.tmp run data get entity @s Count
execute if score #c td.tmp matches ..0 run scoreboard players set #c td.tmp 1
scoreboard players operation #v td.tmp *= #c td.tmp
scoreboard players operation @n[type=minecraft:item_display,tag=td.self] td.xp += #v td.tmp
playsound minecraft:entity.experience_orb.pickup player @a ~ ~ ~ 0.3 1.6
kill @s
