# En tant qu'objet porté : si son disque a disparu (tué, chunk déchargé...), il retombe en objet après 5 ticks
scoreboard players add @s td.life 1
execute if score @s td.life matches 5.. run function throwing_disc:disc/grapple/release_item
