# En tant que disque, à l'endroit où lâcher (pieds du lanceur au rattrapage, position du disque s'il tombe)
execute as @e[type=minecraft:item_display,tag=td.carried] if score @s td.did = #did td.tmp run function throwing_disc:disc/grapple/release_item
execute if score @s td.xp matches 1.. run function throwing_disc:disc/grapple/release_xp
tag @s remove td.has_item
scoreboard players set @s td.xp 0
