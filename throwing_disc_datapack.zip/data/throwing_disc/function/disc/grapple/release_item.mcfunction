# En tant qu'objet porté (item_display) : redevient un objet au sol ici, ramassable tout de suite
summon minecraft:item ~ ~ ~ {Tags:["td.newitem"],PickupDelay:0s,Item:{id:"minecraft:stone",count:1}}
data modify entity @n[type=minecraft:item,tag=td.newitem] Item set from entity @s item
tag @e[type=minecraft:item,tag=td.newitem] remove td.newitem
kill @s
