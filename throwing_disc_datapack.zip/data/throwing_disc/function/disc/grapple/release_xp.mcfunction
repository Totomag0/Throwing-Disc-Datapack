# En tant que disque : rend l'XP stockée sous forme d'orbe (Raccommodage s'applique normalement)
scoreboard players operation @s td.xp < #max_orb td.tmp
summon minecraft:experience_orb ~ ~ ~ {Value:1s,Tags:["td.neworb"]}
execute store result entity @n[type=minecraft:experience_orb,tag=td.neworb] Value short 1 run scoreboard players get @s td.xp
tag @e[type=minecraft:experience_orb,tag=td.neworb] remove td.neworb
