# Grappin (custom) : en tant que disque, à sa position (appelé à chaque pas de 0.2 bloc).
# Ramasse SOIT un objet au sol (une pile entière, 1 à 99), SOIT des orbes d'XP, jamais les deux :
# le premier type ramassé bloque l'autre jusqu'au retour du disque.
execute if entity @s[tag=td.has_item] run return 0
execute unless score @s td.xp matches 1.. as @n[type=minecraft:item,distance=..1.2] run function throwing_disc:disc/grapple/grab_item
execute if entity @s[tag=td.has_item] run return 0
execute as @e[type=minecraft:experience_orb,distance=..1.5] run function throwing_disc:disc/grapple/grab_xp
