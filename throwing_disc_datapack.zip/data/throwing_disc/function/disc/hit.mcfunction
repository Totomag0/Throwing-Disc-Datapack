# En tant qu'entité touchée. Les frames d'invulnérabilité vanilla empêchent les dégâts multiples
# dans le même passage ; l'aller et le retour peuvent chacun toucher.
scoreboard players operation #hit td.tmp = #dmg10 td.tmp

# Châtiment (Smite) : +2.5 x niveau contre les morts-vivants
execute if score #smite td.tmp matches 1.. if entity @s[type=#minecraft:sensitive_to_smite] run function throwing_disc:disc/ench/smite
# Fléau des arthropodes : +2.5 x niveau contre les arthropodes
execute if score #bane td.tmp matches 1.. if entity @s[type=#minecraft:sensitive_to_bane_of_arthropods] run function throwing_disc:disc/ench/bane

execute store result storage throwing_disc:tmp hit.amount float 0.1 run scoreboard players get #hit td.tmp
scoreboard players set #ok td.tmp 0
# Butin (Looting) : le disque est mis le temps du coup dans la main du lanceur pour que le butin vanilla s'applique
execute if score #loot td.tmp matches 1.. run function throwing_disc:disc/ench/looting
execute unless score #loot td.tmp matches 1.. run function throwing_disc:disc/deal with storage throwing_disc:tmp hit
# Les effets ne s'appliquent que si le coup a vraiment porté
execute if score #ok td.tmp matches 0 run return 0

execute at @s run particle minecraft:crit ~ ~1 ~ 0.2 0.3 0.2 0.1 4
execute if score #bane td.tmp matches 1.. if entity @s[type=#minecraft:sensitive_to_bane_of_arthropods] run effect give @s minecraft:slowness 2 3
execute if score #fire td.tmp matches 1.. run function throwing_disc:disc/ench/fire
