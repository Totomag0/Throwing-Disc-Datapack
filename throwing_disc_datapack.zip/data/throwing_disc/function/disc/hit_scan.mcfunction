# Toutes les entités dont la hitbox touche un cube d'1 bloc centré sur le disque (perce à travers)
# Avec Colosse, le cube grandit avec le disque.
execute if score #colossus td.tmp matches 1.. run return run function throwing_disc:disc/hit_scan_big with storage throwing_disc:tmp box
execute positioned ~-0.5 ~-0.5 ~-0.5 as @e[dx=0,dy=0,dz=0,type=!#throwing_disc:not_hittable,tag=!td.owner] run function throwing_disc:disc/hit
