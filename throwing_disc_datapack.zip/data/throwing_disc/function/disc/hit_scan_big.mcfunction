$execute positioned ~$(o) ~$(o) ~$(o) as @e[dx=$(d),dy=$(d),dz=$(d),type=!#throwing_disc:not_hittable,tag=!td.owner] run function throwing_disc:disc/hit
