# Retourne 1 si la durabilité du disque est épuisée
execute store result score #dmg td.tmp run data get entity @s item.components."minecraft:damage"
execute store result score #max td.tmp run data get entity @s item.components."minecraft:max_damage"
execute if score #dmg td.tmp >= #max td.tmp run return 1
return 0
