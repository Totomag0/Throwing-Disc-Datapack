# Un pas de 0.2 bloc à l'aller
execute at @s if block ^ ^ ^0.2 minecraft:decorated_pot positioned ^ ^ ^0.2 run function throwing_disc:disc/break_pot
execute at @s unless block ^ ^ ^0.2 #throwing_disc:passable run function throwing_disc:disc/ricochet
execute at @s if block ^ ^ ^0.2 #throwing_disc:passable run tp @s ^ ^ ^0.2
execute at @s run function throwing_disc:disc/hit_scan
execute if score #grapple td.tmp matches 1.. at @s run function throwing_disc:disc/grapple/scan

scoreboard players remove #steps td.tmp 1
execute if score #steps td.tmp matches 1.. if score @s td.phase matches 1 run function throwing_disc:disc/out_step
