# Phase 1 : aller en ligne droite (pas de gravité)
scoreboard players remove @s td.timer 1
execute if score #steps td.tmp matches 1.. run function throwing_disc:disc/out_step
execute if score @s td.timer matches ..0 run scoreboard players set @s td.phase 2
