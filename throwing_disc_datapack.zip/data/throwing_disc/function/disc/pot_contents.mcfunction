# Fait tomber l'item stocké dans le pot, puis le vide pour qu'il ne soit pas lâché une 2e fois
summon minecraft:item ~ ~ ~ {Tags:["td.newitem"],Item:{id:"minecraft:stick",count:1}}
data modify entity @n[type=minecraft:item,tag=td.newitem] Item set from block ~ ~ ~ item
tag @n[type=minecraft:item,tag=td.newitem] remove td.newitem
data remove block ~ ~ ~ item
