# Un pas de 0.2 bloc au retour
execute at @s if block ^ ^ ^0.2 minecraft:decorated_pot positioned ^ ^ ^0.2 run function throwing_disc:disc/break_pot
execute at @s run tp @s ^ ^ ^0.2
execute at @s run function throwing_disc:disc/hit_scan
execute if score #grapple td.tmp matches 1.. at @s run function throwing_disc:disc/grapple/scan
execute at @s positioned ~ ~-1.62 ~ if entity @a[tag=td.owner,distance=..1.6] run return run function throwing_disc:disc/catch

scoreboard players remove #steps td.tmp 1
execute if score #steps td.tmp matches 1.. run function throwing_disc:disc/ret_step
