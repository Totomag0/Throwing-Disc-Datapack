# Phase 2 : retour vers les yeux du lanceur, traverse les blocs (comme un trident Loyauté), accélère
scoreboard players add @s td.speed 6
scoreboard players operation @s td.speed < #max_return td.tmp
execute at @s facing entity @a[tag=td.owner,limit=1] eyes run tp @s ~ ~ ~ ~ ~
execute at @s positioned ~ ~-1.62 ~ if entity @a[tag=td.owner,distance=..1.6] run return run function throwing_disc:disc/catch
execute if score #steps td.tmp matches 1.. run function throwing_disc:disc/ret_step
