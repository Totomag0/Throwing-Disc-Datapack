# Le prochain pas touche un bloc dur : réflexion sur l'axe (ou les axes) touché(s)
# Direction : dx = -sin(yaw), dz = cos(yaw), dy = -sin(pitch)
execute store result score @s td.yaw run data get entity @s Rotation[0] 100
execute store result score @s td.pitch run data get entity @s Rotation[1] 100
# Normalise le yaw dans [-180 ; 180[
scoreboard players operation @s td.yaw += #18000 td.tmp
scoreboard players operation @s td.yaw %= #36000 td.tmp
scoreboard players operation @s td.yaw -= #18000 td.tmp

scoreboard players set #rx td.tmp 0
scoreboard players set #rz td.tmp 0
scoreboard players set #ry td.tmp 0
execute if score @s td.yaw matches -17500..-500 unless block ~0.3 ~ ~ #throwing_disc:passable run scoreboard players set #rx td.tmp 1
execute if score @s td.yaw matches 500..17500 unless block ~-0.3 ~ ~ #throwing_disc:passable run scoreboard players set #rx td.tmp 1
execute if score @s td.yaw matches -8500..8500 unless block ~ ~ ~0.3 #throwing_disc:passable run scoreboard players set #rz td.tmp 1
execute unless score @s td.yaw matches -9499..9499 unless block ~ ~ ~-0.3 #throwing_disc:passable run scoreboard players set #rz td.tmp 1
execute if score @s td.pitch matches ..-500 unless block ~ ~0.3 ~ #throwing_disc:passable run scoreboard players set #ry td.tmp 1
execute if score @s td.pitch matches 500.. unless block ~ ~-0.3 ~ #throwing_disc:passable run scoreboard players set #ry td.tmp 1

# Réflexions : X -> yaw = -yaw ; Z -> yaw = 180 - yaw ; Y -> pitch = -pitch
execute if score #rx td.tmp matches 1 run scoreboard players operation @s td.yaw *= #-1 td.tmp
execute if score #rz td.tmp matches 1 run scoreboard players operation @s td.yaw *= #-1 td.tmp
execute if score #rz td.tmp matches 1 run scoreboard players operation @s td.yaw += #18000 td.tmp
execute if score #ry td.tmp matches 1 run scoreboard players operation @s td.pitch *= #-1 td.tmp
# Coin / angle mort : demi-tour complet
scoreboard players operation #any td.tmp = #rx td.tmp
scoreboard players operation #any td.tmp += #rz td.tmp
scoreboard players operation #any td.tmp += #ry td.tmp
execute if score #any td.tmp matches 0 run scoreboard players operation @s td.yaw += #18000 td.tmp
execute if score #any td.tmp matches 0 run scoreboard players operation @s td.pitch *= #-1 td.tmp

execute store result entity @s Rotation[0] float 0.01 run scoreboard players get @s td.yaw
execute store result entity @s Rotation[1] float 0.01 run scoreboard players get @s td.pitch

# Après un ricochet : plus rapide (+~14 %) et vole plus longtemps
scoreboard players operation #add td.tmp = @s td.speed
scoreboard players operation #add td.tmp /= #7 td.tmp
scoreboard players operation @s td.speed += #add td.tmp
scoreboard players operation @s td.speed < #max_speed td.tmp
scoreboard players add @s td.timer 4

scoreboard players add @s td.bounce 1
execute if score @s td.bounce >= #max_bounce td.tmp run scoreboard players set @s td.phase 2

particle minecraft:crit ~ ~ ~ 0.1 0.1 0.1 0.25 8
playsound minecraft:item.trident.hit_ground player @a ~ ~ ~ 0.8 1.5
