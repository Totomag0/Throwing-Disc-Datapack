# En tant que disque : fait apparaître l'item à la position courante (ramassable tout de suite)
summon minecraft:item ~ ~ ~ {Tags:["td.newitem"],PickupDelay:0s,Item:{id:"minecraft:stick",count:1}}
data modify entity @n[type=minecraft:item,tag=td.newitem] Item set from entity @s item
tag @n[type=minecraft:item,tag=td.newitem] remove td.newitem
