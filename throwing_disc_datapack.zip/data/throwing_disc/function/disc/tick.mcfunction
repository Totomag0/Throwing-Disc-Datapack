# En tant que disque, à sa position
scoreboard players add @s td.life 1

# Retrouve le lanceur
tag @a[tag=td.owner] remove td.owner
scoreboard players operation #owner td.tmp = @s td.owner
execute as @a if score @s td.id = #owner td.tmp run tag @s add td.owner
tag @e[type=minecraft:item_display,tag=td.self] remove td.self
tag @s add td.self
scoreboard players operation #did td.tmp = @s td.did
function throwing_disc:disc/read_enchants

# Lanceur absent / trop loin / autre dimension, ou vol trop long : le disque tombe au sol
execute unless entity @a[tag=td.owner,distance=..96] run return run function throwing_disc:disc/drop
execute if score @s td.life matches 400.. run return run function throwing_disc:disc/drop

# Nombre de pas de 0.2 bloc ce tick (accumulateur pour garder la précision)
scoreboard players operation @s td.acc += @s td.speed
scoreboard players operation #steps td.tmp = @s td.acc
scoreboard players operation #steps td.tmp /= #20 td.tmp
scoreboard players operation @s td.acc %= #20 td.tmp

# Son de rotation
scoreboard players operation #m td.tmp = @s td.life
scoreboard players operation #m td.tmp %= #4 td.tmp
execute if score #m td.tmp matches 0 run playsound minecraft:entity.player.attack.sweep player @a ~ ~ ~ 0.25 1.9

# Phase lue avant le mouvement : l'aller qui se termine ne lance le retour qu'au tick suivant
scoreboard players operation #ph td.tmp = @s td.phase
execute if score #ph td.tmp matches 1 run function throwing_disc:disc/outbound
execute if score #ph td.tmp matches 2.. run function throwing_disc:disc/return

# Tornade : attire les mobs autour du disque
execute if score #tornado td.tmp matches 1.. at @s run function throwing_disc:disc/ench/tornado

# Grappin : l'objet porté suit le disque, l'XP stockée brille
execute if entity @s[tag=td.has_item] at @s run function throwing_disc:disc/grapple/carry
execute if score @s td.xp matches 1.. if score #m td.tmp matches 0 at @s run particle minecraft:happy_villager ~ ~ ~ 0.15 0.15 0.15 0 1
