# Clic droit sur les items de base (détection du lancer)
scoreboard objectives add td.use_c minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add td.use_w minecraft.used:minecraft.warped_fungus_on_a_stick

# Joueurs
scoreboard objectives add td.id dummy

# Disques en vol
scoreboard objectives add td.owner dummy
scoreboard objectives add td.hand dummy
scoreboard objectives add td.phase dummy
scoreboard objectives add td.timer dummy
scoreboard objectives add td.speed dummy
scoreboard objectives add td.acc dummy
scoreboard objectives add td.bounce dummy
scoreboard objectives add td.life dummy
scoreboard objectives add td.yaw dummy
scoreboard objectives add td.pitch dummy
scoreboard objectives add td.tmp dummy
# Identifiant unique de chaque disque (relie un objet porté par Grappin à son disque) et XP stockée par Grappin
scoreboard objectives add td.did dummy
scoreboard objectives add td.xp dummy
# Colosse : progression de croissance (0-1000) et distance² au début du retour
scoreboard objectives add td.prog dummy
scoreboard objectives add td.d0 dummy

# Constantes
scoreboard players set #-1 td.tmp -1
scoreboard players set #2 td.tmp 2
scoreboard players set #4 td.tmp 4
scoreboard players set #5 td.tmp 5
scoreboard players set #25 td.tmp 25
scoreboard players set #80 td.tmp 80
scoreboard players set #50 td.tmp 50
scoreboard players set #10 td.tmp 10
scoreboard players set #100 td.tmp 100
scoreboard players set #500 td.tmp 500
# Valeur max d'une orbe d'XP rendue par Grappin
scoreboard players set #max_orb td.tmp 32767
scoreboard players set #7 td.tmp 7
scoreboard players set #20 td.tmp 20
scoreboard players set #18000 td.tmp 18000
scoreboard players set #36000 td.tmp 36000
# Vitesse max après ricochets (x100 blocs/tick) et vitesse max au retour
scoreboard players set #max_speed td.tmp 250
scoreboard players set #max_return td.tmp 300
# Nombre max de ricochets avant retour forcé
scoreboard players set #max_bounce td.tmp 8
