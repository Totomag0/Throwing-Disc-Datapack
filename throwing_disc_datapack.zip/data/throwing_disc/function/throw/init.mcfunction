# En tant que disque fraîchement lancé
scoreboard players operation @s td.hand = #hand td.tmp
scoreboard players set @s td.phase 1
scoreboard players set @s td.bounce 0
scoreboard players set @s td.life 0
scoreboard players set @s td.acc 0
scoreboard players set @s td.xp 0
scoreboard players set @s td.prog 0
scoreboard players set @s td.d0 0
execute store result score @s td.did run scoreboard players add #next td.did 1
execute store result score @s td.speed run data get entity @s item.components."minecraft:custom_data".td_disc.speed
execute store result score @s td.timer run data get entity @s item.components."minecraft:custom_data".td_disc.range

# Passe au modèle animé pendant le vol
data modify entity @s item.components."minecraft:item_model" set from entity @s item.components."minecraft:custom_data".td_disc.thrown_model

execute if score #creative td.tmp matches 0 run function throwing_disc:throw/wear
tag @s remove td.new
playsound minecraft:item.trident.throw player @a ~ ~ ~ 1 1.4
