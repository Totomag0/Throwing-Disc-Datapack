scoreboard players set #hand td.tmp 1
execute anchored eyes positioned ^ ^-0.15 ^0.4 run function throwing_disc:throw/spawn
item replace entity @n[type=minecraft:item_display,tag=td.new] contents from entity @s weapon.mainhand
item replace entity @s weapon.mainhand with minecraft:air
function throwing_disc:throw/setup
