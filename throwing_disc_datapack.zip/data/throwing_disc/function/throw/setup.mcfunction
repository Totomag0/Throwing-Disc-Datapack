# En tant que joueur : relie le disque à son lanceur
scoreboard players operation @n[type=minecraft:item_display,tag=td.new] td.owner = @s td.id
execute store success score #creative td.tmp if entity @s[gamemode=creative]
execute as @n[type=minecraft:item_display,tag=td.new] run function throwing_disc:throw/init
