# Positionné devant les yeux du joueur, avec sa rotation.
# item_display "none" : on ignore les réglages d'affichage du model (pas de "fixed").
# Une rotation de 90° sur X couche le model d'animation à l'horizontale (validé en jeu).
# Il suit ensuite la direction du regard.
summon minecraft:item_display ~ ~ ~ {Tags:["td.disc","td.new"],teleport_duration:1,item_display:"none",transformation:{left_rotation:{angle:1.5708f,axis:[1f,0f,0f]},right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1f,1f,1f]},item:{id:"minecraft:stick",count:1}}
tp @n[type=minecraft:item_display,tag=td.new] ~ ~ ~ ~ ~
