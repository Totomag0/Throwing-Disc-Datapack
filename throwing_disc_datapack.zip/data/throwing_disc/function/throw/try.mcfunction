# En tant que joueur qui vient de faire clic droit
# Sur un cochon ou un arpenteur, le clic droit garde son effet vanilla
execute on vehicle if entity @s[type=minecraft:pig] run return fail
execute on vehicle if entity @s[type=minecraft:strider] run return fail

execute if items entity @s weapon.mainhand *[minecraft:custom_data~{td_disc:{}}] run return run function throwing_disc:throw/mainhand
execute if items entity @s weapon.offhand *[minecraft:custom_data~{td_disc:{}}] run function throwing_disc:throw/offhand
