# -1 durabilité par lancer, en respectant Solidité (Unbreaking) : chance 1/(niveau+1)
execute store result score #ub td.tmp run data get entity @s item.components."minecraft:enchantments"."minecraft:unbreaking"
scoreboard players add #ub td.tmp 1
scoreboard players set #chance td.tmp 100
scoreboard players operation #chance td.tmp /= #ub td.tmp
execute store result score #r td.tmp run random value 0..99
execute if score #r td.tmp >= #chance td.tmp run return 0

execute store result score #dmg td.tmp run data get entity @s item.components."minecraft:damage"
scoreboard players add #dmg td.tmp 1
execute store result entity @s item.components."minecraft:damage" int 1 run scoreboard players get #dmg td.tmp
