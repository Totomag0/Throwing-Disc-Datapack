# Identifiant unique par joueur (pour relier un disque à son lanceur)
execute as @a unless score @s td.id matches 1.. store result score @s td.id run scoreboard players add #next td.id 1

# Lancers
execute as @a[scores={td.use_c=1..}] at @s run function throwing_disc:throw/try
execute as @a[scores={td.use_w=1..}] at @s run function throwing_disc:throw/try
scoreboard players reset @a[scores={td.use_c=1..}] td.use_c
scoreboard players reset @a[scores={td.use_w=1..}] td.use_w

# Disques en vol
execute as @e[type=minecraft:item_display,tag=td.disc] at @s run function throwing_disc:disc/tick

# Objets portés par Grappin dont le disque n'existe plus
execute as @e[type=minecraft:item_display,tag=td.carried] at @s run function throwing_disc:disc/grapple/orphan
