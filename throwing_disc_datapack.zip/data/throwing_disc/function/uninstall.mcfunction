# Fait tomber les disques en vol puis supprime les scoreboards du pack
execute as @e[type=minecraft:item_display,tag=td.disc] at @s run function throwing_disc:disc/drop
scoreboard objectives remove td.use_c
scoreboard objectives remove td.use_w
scoreboard objectives remove td.id
scoreboard objectives remove td.owner
scoreboard objectives remove td.hand
scoreboard objectives remove td.phase
scoreboard objectives remove td.timer
scoreboard objectives remove td.speed
scoreboard objectives remove td.acc
scoreboard objectives remove td.bounce
scoreboard objectives remove td.life
scoreboard objectives remove td.yaw
scoreboard objectives remove td.pitch
scoreboard objectives remove td.tmp
scoreboard objectives remove td.did
scoreboard objectives remove td.xp
scoreboard objectives remove td.prog
scoreboard objectives remove td.d0
data remove storage throwing_disc:tmp hit
data remove storage throwing_disc:tmp box
