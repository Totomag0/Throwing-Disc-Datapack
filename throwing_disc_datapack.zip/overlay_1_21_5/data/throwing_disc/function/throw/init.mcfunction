# En tant que disque fraîchement lancé (version 1.21.5 - 1.21.10)
scoreboard players operation @s td.hand = #hand td.tmp
scoreboard players set @s td.phase 1
scoreboard players set @s td.bounce 0
scoreboard players set @s td.life 0
scoreboard players set @s td.acc 0
scoreboard players set @s td.xp 0
scoreboard players set @s td.prog 0
scoreboard players set @s td.d0 0
execute store result score @s td.did run scoreboard players add #next td.did 1
execute store result score @s td.speed run data get entity @s item.components."minecraft:custom_data".td_disc.speed
execute store result score @s td.timer run data get entity @s item.components."minecraft:custom_data".td_disc.range

# Pas de changement de model : le model "_animation" ne se charge pas avant la 1.21.11.
# Le model en main est affiché avec la rotation de l'animation (voir throw/spawn).

execute if score #creative td.tmp matches 0 run function throwing_disc:throw/wear
tag @s remove td.new
playsound minecraft:item.trident.throw player @a ~ ~ ~ 1 1.4
