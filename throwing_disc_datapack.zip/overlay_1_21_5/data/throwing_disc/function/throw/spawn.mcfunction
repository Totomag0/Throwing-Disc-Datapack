# Version 1.21.5 - 1.21.10 : les models "_animation" du resource pack utilisent la rotation libre de la 1.21.11,
# illisible avant. On affiche donc le model en main (même géométrie) avec la rotation de l'animation
# (90° sur Y) combinée à celle qui couche le disque (90° sur X) : quaternion [0.5, 0.5, 0.5, 0.5].
summon minecraft:item_display ~ ~ ~ {Tags:["td.disc","td.new"],teleport_duration:1,item_display:"none",transformation:{left_rotation:[0.5f,0.5f,0.5f,0.5f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1f,1f,1f]},item:{id:"minecraft:stick",count:1}}
tp @n[type=minecraft:item_display,tag=td.new] ~ ~ ~ ~ ~
